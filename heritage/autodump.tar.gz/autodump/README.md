# 使用說明
## 前置動作
- Linux only(在Windows上仍可使用`shepher.py`)
- 須安裝套件：`curl`,`w3m`,`python3`
- 首次執行請記得`chmod +x dump.sh`
- 需要有網路連線
## 使用步驟
- 移動至希望檔案生成的資料夾，執行`dump.sh`
- 目標檔案將是`Axx_xxs.txt`
- **不會**自動刪除raw files.
