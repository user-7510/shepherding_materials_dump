#!/bin/bash
read -p "請輸入系列編號（例如 01）：" series
read -p "請輸入章節編號（例如 12）：" chapter
curl -O "https://www.churchintaichung.org/shepherding_materials/series${series}/A${series}_${chapter}.pdf"
pdftohtml -s "A${series}_${chapter}.pdf"
w3m -dump "A${series}_${chapter}-html.html" > "A${series}_${chapter}.txt"
python3 shepher.py "A${series}_${chapter}.txt" > "A${series}_${chapter}s.txt"
